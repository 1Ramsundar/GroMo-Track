import React from 'react';
import DashboardLayout from '../components/layout/DashboardLayout';
import DashboardStats from '../components/dashboard/DashboardStats';
import SpendingChart from '../components/dashboard/SpendingChart';
import BudgetCard from '../components/dashboard/BudgetCard';
import QuickActions from '../components/dashboard/QuickActions';
import RecentTransactions from '../components/dashboard/RecentTransactions';
/*import UpcomingBills from '../components/dashboard/UpcomingBills';*/
import FinancialHealth from '../components/dashboard/FinancialHealth';
import { useAuth } from '../context/AuthContext';

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good Morning';
  if (hour < 18) return 'Good Afternoon';
  return 'Good Evening';
}

export default function Dashboard() {
  const { user } = useAuth();
  const greeting = getGreeting();
  
  return (
    <DashboardLayout>
      {/* Greeting */}
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-slate-900 font-[family-name:var(--font-heading)]">
          {greeting}, {user?.fullName?.split(' ')[0] || 'User'} 👋
        </h1>
        <p className="mt-1 text-slate-500">Here's your financial overview</p>
      </div>
      
      {/* KPI Cards */}
      <DashboardStats />
      
      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6 mt-8">
        <div className="lg:col-span-2">
          <SpendingChart />
        </div>
        <BudgetCard />
      </div>
      
      {/* Quick Actions */}
      <div className="mt-8">
        <QuickActions />
      </div>
      
      {/* Bottom Row */}
      <div className="grid lg:grid-cols-3 gap-6 mt-8">
        <div className="lg:col-span-2">
          <RecentTransactions />
        </div>
        <div className="space-y-6">
           <FinancialHealth /> 
           {/*<UpcomingBills />*/}
        </div>
      </div>
    </DashboardLayout>
  );
}