import { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';

const ExpenseContext = createContext();

export const useExpenses = () => {
  const context = useContext(ExpenseContext);
  if (!context) {
    throw new Error('useExpenses must be used within an ExpenseProvider');
  }
  return context;
};

export const ExpenseProvider = ({ children }) => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('gromo_expenses');
      if (stored) {
        setExpenses(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading expenses', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Save to localStorage whenever expenses change
  useEffect(() => {
    if (!loading) {
      localStorage.setItem('gromo_expenses', JSON.stringify(expenses));
    }
  }, [expenses, loading]);

  const addExpense = useCallback((expenseData) => {
    const newExpense = {
      id: crypto.randomUUID(),
      ...expenseData,
      createdAt: new Date().toISOString()
    };
    setExpenses(prev => [...prev, newExpense]);
    return newExpense;
  }, []);

  const updateExpense = useCallback((id, updatedExpense) => {
    setExpenses(prev => prev.map(exp => (exp.id === id ? { ...exp, ...updatedExpense } : exp)));
  }, []);

  const deleteExpense = useCallback((id) => {
    setExpenses(prev => prev.filter(exp => exp.id !== id));
  }, []);

  const getExpensesByDateRange = useCallback((startDate, endDate) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return expenses.filter(exp => {
      const date = new Date(exp.date);
      return date >= start && date <= end;
    });
  }, [expenses]);

  const getExpensesByCategory = useCallback((category) => {
    return expenses.filter(exp => exp.category === category);
  }, [expenses]);

  const getTotalByCategory = useCallback(() => {
    return expenses.reduce((acc, exp) => {
      acc[exp.category] = (acc[exp.category] || 0) + Number(exp.amount);
      return acc;
    }, {});
  }, [expenses]);

  const getTotalByPaymentMethod = useCallback(() => {
    return expenses.reduce((acc, exp) => {
      acc[exp.paymentMethod] = (acc[exp.paymentMethod] || 0) + Number(exp.amount);
      return acc;
    }, {});
  }, [expenses]);

  const getDailyTotals = useCallback((month, year) => {
    const daysInMonth = new Date(year, month, 0).getDate();
    const dailyTotals = Array.from({ length: daysInMonth }, (_, i) => ({
      date: i + 1,
      total: 0
    }));

    expenses.forEach(exp => {
      const date = new Date(exp.date);
      if (date.getMonth() + 1 === month && date.getFullYear() === year) {
        const day = date.getDate();
        dailyTotals[day - 1].total += Number(exp.amount);
      }
    });

    return dailyTotals;
  }, [expenses]);

  const getMonthlyTotals = useCallback((year) => {
    const monthlyTotals = Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      total: 0
    }));

    expenses.forEach(exp => {
      const date = new Date(exp.date);
      if (date.getFullYear() === year) {
        const month = date.getMonth();
        monthlyTotals[month].total += Number(exp.amount);
      }
    });

    return monthlyTotals;
  }, [expenses]);

  const getWeeklyTotals = useCallback(() => {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const diff = now.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
    const startOfWeek = new Date(now.setDate(diff));
    startOfWeek.setHours(0, 0, 0, 0);

    const weeklyTotals = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => ({
      day,
      total: 0
    }));

    expenses.forEach(exp => {
      const date = new Date(exp.date);
      if (date >= startOfWeek) {
        let dayIdx = date.getDay() - 1;
        if (dayIdx === -1) dayIdx = 6; // Sunday
        if (dayIdx >= 0 && dayIdx <= 6) {
          weeklyTotals[dayIdx].total += Number(exp.amount);
        }
      }
    });

    return weeklyTotals;
  }, [expenses]);

  const getTotalSpent = useCallback((month, year) => {
    return expenses.reduce((acc, exp) => {
      const date = new Date(exp.date);
      if (date.getMonth() + 1 === month && date.getFullYear() === year) {
        return acc + Number(exp.amount);
      }
      return acc;
    }, 0);
  }, [expenses]);

  const clearAllExpenses = useCallback(() => {
    setExpenses([]);
  }, []);

  const value = useMemo(() => ({
    expenses,
    loading,
    addExpense,
    updateExpense,
    deleteExpense,
    getExpensesByDateRange,
    getExpensesByCategory,
    getTotalByCategory,
    getTotalByPaymentMethod,
    getDailyTotals,
    getMonthlyTotals,
    getWeeklyTotals,
    getTotalSpent,
    clearAllExpenses
  }), [
    expenses, loading, addExpense, updateExpense, deleteExpense,
    getExpensesByDateRange, getExpensesByCategory, getTotalByCategory,
    getTotalByPaymentMethod, getDailyTotals, getMonthlyTotals,
    getWeeklyTotals, getTotalSpent, clearAllExpenses
  ]);

  return (
    <ExpenseContext.Provider value={value}>
      {children}
    </ExpenseContext.Provider>
  );
};
