import React from 'react';
import { Button } from '../ui/Button';
import { FileText, Sheet, Table } from 'lucide-react';
import toast from 'react-hot-toast';

export function ReportDownload({ expenses, summary, period }) {
  // Mock implementations for downloading
  const handleDownload = (format) => {
    if (expenses.length === 0) {
      toast.error('No expenses to download.');
      return;
    }
    toast.success(`Downloading ${format} report for ${period}...`);
    // Here we would call the actual utility functions
  };

  return (
    <div className="flex flex-wrap gap-4 mt-6">
      <Button 
        variant="outline" 
        icon={FileText} 
        onClick={() => handleDownload('PDF')}
      >
        Download PDF
      </Button>
      <Button 
        variant="outline" 
        icon={Sheet} 
        onClick={() => handleDownload('CSV')}
      >
        Download CSV
      </Button>
      <Button 
        variant="outline" 
        icon={Table} 
        onClick={() => handleDownload('Excel')}
      >
        Download Excel
      </Button>
    </div>
  );
}
