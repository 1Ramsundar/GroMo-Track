import React from 'react';
import { Card } from '../ui/Card';
import { Toggle } from '../ui/Toggle';
import { useSettings } from '../../context/SettingsContext';

export function NotificationSettings() {
  const { notifications, setNotifications } = useSettings();

  const toggleNotification = (key) => {
    // In a real app, update via context
  };

  return (
    <Card title="Notifications" padding="lg">
      <div className="space-y-6">
        <Toggle
          label="Budget Alerts"
          description="Receive an alert when you exceed 80% of your budget for any category."
          checked={notifications?.budgetAlerts ?? true}
          onChange={() => toggleNotification('budgetAlerts')}
        />
        <Toggle
          label="Weekly Summary"
          description="Get a weekly email summary of your spending and savings."
          checked={notifications?.weeklySummary ?? true}
          onChange={() => toggleNotification('weeklySummary')}
        />
      </div>
    </Card>
  );
}
