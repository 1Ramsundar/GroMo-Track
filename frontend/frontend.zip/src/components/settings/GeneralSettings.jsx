import React from 'react';
import { Card } from '../ui/Card';
import { Select } from '../ui/Select';
import { Toggle } from '../ui/Toggle';
import { useSettings } from '../../context/SettingsContext';

export function GeneralSettings() {
  const { currency, setCurrency, theme, setTheme } = useSettings();

  const currencies = [
    { label: '₹ INR (Indian Rupee)', value: '₹' },
    { label: '$ USD (US Dollar)', value: '$' },
    { label: '€ EUR (Euro)', value: '€' },
    { label: '£ GBP (British Pound)', value: '£' }
  ];

  const languages = [
    { label: 'English', value: 'en' }
  ];

  return (
    <Card title="General Settings" padding="lg">
      <div className="space-y-6 max-w-md">
        <Select
          label="Currency"
          options={currencies}
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
        />
        
        <Select
          label="Language"
          options={languages}
          value="en"
          onChange={() => {}}
          disabled
        />
        
        <div className="pt-2">
          <Toggle
            label="Dark Mode"
            description="Toggle dark mode theme (Coming Soon)"
            checked={theme === 'dark'}
            onChange={(e) => setTheme(e.target.checked ? 'dark' : 'light')}
          />
        </div>
      </div>
    </Card>
  );
}
