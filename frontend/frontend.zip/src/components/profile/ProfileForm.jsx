import React, { useState } from 'react';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export function ProfileForm() {
  const { user, login } = useAuth();
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = (e) => {
    e.preventDefault();
    if (formData.newPassword && formData.newPassword !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    // In a real app, update via API. Here we update context/localStorage
    const updatedUser = { ...user, name: formData.name };
    localStorage.setItem('user', JSON.stringify(updatedUser));
    // Re-login to update context
    login(updatedUser.email, 'dummy'); // Assuming login just sets the user if we modify it a bit, or we just rely on page reload for now. Actually, since auth is backend, we just pretend for now.
    toast.success('Profile updated successfully');
    
    setFormData(prev => ({ ...prev, currentPassword: '', newPassword: '', confirmPassword: '' }));
  };

  return (
    <Card title="Personal Information" padding="lg">
      <form onSubmit={handleSave} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Input 
            label="Full Name" 
            name="name" 
            value={formData.name} 
            onChange={handleChange} 
          />
          <Input 
            label="Email Address" 
            name="email" 
            value={user?.email || ''} 
            disabled 
            readOnly 
          />
        </div>
        
        <div className="border-t border-slate-200 pt-6">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Change Password</h3>
          <div className="space-y-4 max-w-md">
            <Input 
              type="password" 
              label="Current Password" 
              name="currentPassword" 
              value={formData.currentPassword} 
              onChange={handleChange} 
            />
            <Input 
              type="password" 
              label="New Password" 
              name="newPassword" 
              value={formData.newPassword} 
              onChange={handleChange} 
            />
            <Input 
              type="password" 
              label="Confirm New Password" 
              name="confirmPassword" 
              value={formData.confirmPassword} 
              onChange={handleChange} 
            />
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button type="submit" variant="primary">Save Changes</Button>
        </div>
      </form>
    </Card>
  );
}
